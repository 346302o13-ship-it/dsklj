# CIS 304 – Topology 14 – Hotel and Conference Center – Implementation Record

Practical part of the CIS 304 project (RIPv2 and OSPF, VLANs, wireless) built and tested in Cisco Packet Tracer 9.0.1.
Every value below was read from the running devices; every result in section 8 is shown in the listed screenshot
(see `Evidence_Index.csv` for the full list).

## 1. Files

| Item | Value |
|---|---|
| Packet Tracer | 9.0.1 (Windows) |
| Reference | CIS 304 Project Instructions 2026 – Topology 14; organisation idea 1: Hotel and Conference Center |
| Project files | `CIS304_T14_Hotel_RIPv2.pkt`, `CIS304_T14_Hotel_OSPF.pkt` |
| Difference between the files | Only the routing protocol on R1, R2, R3 (OSPF file made from the RIP file with `no router rip` + `router ospf 1`). Devices, cabling, VLANs, addressing, wireless, ACLs and layout are identical. |
| Device configurations | `configs/RIPv2/R1-R3`, `configs/OSPF/R1-R3`, `configs/Switches/S1-S6` (startup-configs after `write memory`) |
| Evidence | `screenshots/` – 72 original PNG captures of the Packet Tracer device window or full application window (title bar visible), not edited |

How the work was done: devices, cabling, IOS commands, host settings, DNS and tests were driven through the Packet
Tracer MCP connector; IOS commands were typed into each device's real CLI tab, and the PNGs were captured from the
device window at that moment. The WLC Config tabs (WLANs, AP groups) and the wireless clients' Config > Wireless0 pages
have no script interface, so those settings were entered directly in the Packet Tracer GUI and captured there.

## 2. Topology and organisation

Topology 14 is kept: **R1** (hotel, left), **R2** (transit, top centre), **R3** (conference centre, right); serial
links R1–R2 and R2–R3 only (no R1–R3 link); **S1, S2** below R1; **S3, S4** below R3; PC1+PC2 on S1, PC3 on S2,
PC4 on S3, DNS server on S4. Two wireless switches (S5, S6) were added on R1/R3's third Gigabit port.

| Building / floor | Department / use | Devices |
|---|---|---|
| Building 1 (Hotel) – Ground floor | Reception (VLAN 10) | S1, PC1, PC2, PR1 |
| Building 1 – First floor | Administration (VLAN 11) | S2, PC3, PC5 |
| Building 1 – Upper (guest-room) floor | Staff Wi-Fi (VLAN 20), Guest Wi-Fi (VLAN 21), WLC management (VLAN 99) | S5, AP1 (staff), AP2 (guest), WC1, LT1 (staff), TB1 + TB2 (guests) |
| Building 2 (Conference Center) | Conference Operations staff (VLAN 30) | S3, PC4, PC6, PR2 |
| Building 2 – server room | Local services (VLAN 31) | S4, DNS1 |
| Building 2 – conference halls | Staff Wi-Fi (VLAN 40), Guest Wi-Fi (VLAN 41), WLC management (VLAN 98) | S6, AP3 (staff), AP4 (guest), WC2, LT2 (staff), LT3 + TB3 (guests) |
| Between buildings | WAN transit | R2 |

Canvas layout (left to right): S5 wireless branch, S1, S2 under R1; S3, S4, S6 wireless branch under R3; R2 on top.
No notes, labels or legends on the canvas.

## 3. Device inventory (31 devices)

| Type | Qty | Model | Names |
|---|---|---|---|
| Router | 3 | Cisco 2911 + HWIC-2T (slot 0/0) | R1, R2, R3 |
| Switch | 4 + 2 | 2960-24TT (S1–S4); 3560-24PS PoE used as L2 (S5, S6 – powers the LAPs) | S1–S6 |
| Desktop PC | 6 | PC-PT | PC1–PC6 |
| Laptop | 3 | Laptop-PT with PT-LAPTOP-NM-1W wireless card | LT1–LT3 |
| Tablet | 3 | TabletPC-PT | TB1–TB3 |
| IP printer | 2 | Printer-PT | PR1 (Building 1), PR2 (Building 2) |
| Wireless LAN controller | 2 | WLC-PT | WC1 (Building 1), WC2 (Building 2) |
| Lightweight AP | 4 | LAP-PT (PoE from S5/S6) | AP1–AP4 |
| Server | 1 | Server-PT | DNS1 |

Cables: copper straight-through for all Ethernet links, serial DTE/DCE for the two WAN links. Packet Tracer also shows a
hidden "Power Distribution Device" in its device count (32); it is not part of the network.

## 4. VLANs, subnets and gateways

| VLAN | Name | Subnet | Gateway (interface) | Access ports |
|---|---|---|---|---|
| 10 | Reception | 192.168.10.0/24 | 192.168.10.1 (R1 G0/0) | S1 Fa0/1–3, G0/1 uplink |
| 11 | Administration | 192.168.11.0/24 | 192.168.11.1 (R1 G0/1) | S2 Fa0/1–2, G0/1 uplink |
| 20 | Hotel-Staff-WiFi | 192.168.20.0/24 | 192.168.20.1 (R1 G0/2.20) | S5 Fa0/1 (AP1) |
| 21 | Hotel-Guest-WiFi | 192.168.21.0/24 | 192.168.21.1 (R1 G0/2.21) | S5 Fa0/2 (AP2) |
| 99 | Hotel-WLC-Mgmt | 192.168.99.0/24 | 192.168.99.1 (R1 G0/2.99) | S5 Fa0/3 (WC1) |
| 30 | Conference-Ops | 192.168.30.0/24 | 192.168.30.1 (R3 G0/0) | S3 Fa0/1–3, G0/1 uplink |
| 31 | Local-Services | 192.168.31.0/24 | 192.168.31.1 (R3 G0/1) | S4 Fa0/1, G0/1 uplink |
| 40 | Conf-Staff-WiFi | 192.168.40.0/24 | 192.168.40.1 (R3 G0/2.40) | S6 Fa0/1 (AP3) |
| 41 | Conf-Guest-WiFi | 192.168.41.0/24 | 192.168.41.1 (R3 G0/2.41) | S6 Fa0/2 (AP4) |
| 98 | Conf-WLC-Mgmt | 192.168.98.0/24 | 192.168.98.1 (R3 G0/2.98) | S6 Fa0/3 (WC2) |

802.1Q trunks: R1 G0/2 ↔ S5 G0/1 (allowed 20,21,99); R3 G0/2 ↔ S6 G0/1 (allowed 40,41,98). Inter-VLAN routing:
router-on-a-stick subinterfaces on G0/2; the four reference LANs use R1/R3 physical interfaces G0/0 and G0/1.

## 5. WAN links

| Link | Interface | Address | DCE/DTE | Clock |
|---|---|---|---|---|
| R1–R2 | R1 S0/0/0 | 10.0.0.1/30 | DTE | – |
| | R2 S0/0/0 | 10.0.0.2/30 | **DCE** (show controllers: DCE V.35) | clock rate 64000 |
| R2–R3 | R2 S0/0/1 | 10.0.0.5/30 | **DCE** | clock rate 64000 |
| | R3 S0/0/0 | 10.0.0.6/30 | DTE | – |

## 6. Static addresses, DHCP and DNS

| Device | Address | Gateway |
|---|---|---|
| DNS1 | 192.168.31.10/24 (DNS server 192.168.31.10) | 192.168.31.1 |
| PR1 | 192.168.10.5/24 | 192.168.10.1 |
| PR2 | 192.168.30.5/24 | 192.168.30.1 |
| WC1 (management) | 192.168.99.2/24 | 192.168.99.1 |
| WC2 (management) | 192.168.98.2/24 | 192.168.98.1 |

DHCP on R1 (pools RECEPTION, ADMINISTRATION, HOTEL-STAFF-WIFI, HOTEL-GUEST-WIFI) and R3 (CONF-OPS, CONF-STAFF-WIFI,
CONF-GUEST-WIFI); `.1–.20` excluded in every pool; DNS server 192.168.31.10; Wi-Fi pools carry `option 43 ip <WLC>` so the
APs find their controller. DNS1 local test records: `dns1.hotel.local → 192.168.31.10`, `printer1.hotel.local → 192.168.10.5`.
(The cloud reservation system is a separate written case study and is not part of this network.)

Observed DHCP addresses: PC1 192.168.10.22, PC2 .10.23, PC3 192.168.11.22, PC5 .11.23, PC4 192.168.30.22,
PC6 .30.23, LT1 192.168.20.22, TB1 192.168.21.23, TB2 .21.24, LT2 192.168.40.23, LT3 192.168.41.22, TB3 .41.24,
AP1 192.168.20.21. (After reopening the RIPv2 file PC1 received 192.168.10.21.)

## 7. Wireless design

| Controller | WLAN / SSID | VLAN | Security | AP group | AP |
|---|---|---|---|---|---|
| WC1 | Hotel-Staff | 20 | WPA2-PSK, AES, passphrase `HotelStaff2026` | Hotel-Staff-Group | AP1 |
| WC1 | Hotel-Guest | 21 | WPA2-PSK, AES, `HotelGuest2026` | Hotel-Guest-Group | AP2 |
| WC2 | Conf-Staff | 40 | WPA2-PSK, AES, `ConfStaff2026` | Conf-Staff-Group | AP3 |
| WC2 | Conf-Guest | 41 | WPA2-PSK, AES, `ConfGuest2026` | Conf-Guest-Group | AP4 |

Mode: local switching, local authentication. Each AP is plugged into an access port of the VLAN it serves and receives
its own address from that VLAN's pool (option 43 → WLC), joins its controller over CAPWAP (status **Online**), and
– through its AP group – broadcasts only one SSID. All four APs were Online on their controller.

**Guest isolation:** extended ACLs `HOTEL-GUEST-IN` (R1 G0/2.21 in) and `CONF-GUEST-IN` (R3 G0/2.41 in) deny the guest
subnet to every internal subnet (10, 11, 20, 99, 30, 40, 98) and permit everything else (gateway, DHCP, DNS1).
Line 5 permits UDP 5246–5247 (CAPWAP) from the guest VLAN to its own controller only. This line was added after testing:
without it the guest AP (addressed in the guest VLAN) could not reach its WLC and guest clients lost service
(screenshot 50 shows 50 matches on the management-VLAN deny before the fix).

## 8. Important commands used

```
R2:  interface Serial0/0/0 / ip address 10.0.0.2 255.255.255.252 / clock rate 64000 / no shutdown
     interface Serial0/0/1 / ip address 10.0.0.5 255.255.255.252 / clock rate 64000 / no shutdown
R1:  interface GigabitEthernet0/2.20 / encapsulation dot1Q 20 / ip address 192.168.20.1 255.255.255.0
     (same for .21 and .99; R3 uses .40, .41, .98)
     ip dhcp excluded-address 192.168.10.1 192.168.10.20
     ip dhcp pool HOTEL-STAFF-WIFI / network 192.168.20.0 255.255.255.0 / default-router 192.168.20.1
       / dns-server 192.168.31.10 / option 43 ip 192.168.99.2
S1:  vlan 10 / name Reception
     interface range FastEthernet0/1 - 3 / switchport mode access / switchport access vlan 10
S5:  interface GigabitEthernet0/1 / switchport trunk encapsulation dot1q / switchport mode trunk
       / switchport trunk allowed vlan 20,21,99
R1:  ip access-list extended HOTEL-GUEST-IN
       5 permit udp 192.168.21.0 0.0.0.255 host 192.168.99.2 range 5246 5247
       deny ip 192.168.21.0 0.0.0.255 192.168.10.0 0.0.0.255   (… 11, 20, 99, 30, 40, 98)
       permit ip any any
     interface GigabitEthernet0/2.21 / ip access-group HOTEL-GUEST-IN in
RIPv2 file:
  R1: router rip / version 2 / no auto-summary / network 10.0.0.0 / network 192.168.10.0 / .11.0 / .20.0 / .21.0 / .99.0
  R2: router rip / version 2 / no auto-summary / network 10.0.0.0
  R3: router rip / version 2 / no auto-summary / network 10.0.0.0 / network 192.168.30.0 / .31.0 / .40.0 / .41.0 / .98.0
OSPF file (no router rip first):
  R1: router ospf 1 / router-id 1.1.1.1 / network 10.0.0.0 0.0.0.3 area 0 / network 192.168.10.0 0.0.0.255 area 0
      (… 11, 20, 21, 99)
  R2: router ospf 1 / router-id 2.2.2.2 / network 10.0.0.0 0.0.0.3 area 0 / network 10.0.0.4 0.0.0.3 area 0
  R3: router ospf 1 / router-id 3.3.3.3 / network 10.0.0.4 0.0.0.3 area 0 / network 192.168.30.0 0.0.0.255 area 0
      (… 31, 40, 41, 98)
All routers/switches: line console 0 / exec-timeout 0 0 ; write memory
```

## 9. Test results

Common test pair in both files: **PC1** (Reception, VLAN 10) → **DNS1 192.168.31.10** (local services, Building 2).
Remote LAN checked on edge router **R1: 192.168.31.0/24**.

| File | Test | Observed result | Screenshot |
|---|---|---|---|
| Common | WAN links | S0/0/0 10.0.0.2 up/up, S0/0/1 10.0.0.5 up/up, clock rate 64000 ×2 | 05 |
| Common | Inter-VLAN PC1 192.168.10.22 → PC3 192.168.11.22 | 4/4, TTL 127 (1st run 3/4 ARP) | 16, 17 |
| Common | DHCP lease PC1 | 192.168.10.22/24, GW .10.1, DHCP server 192.168.10.1, DNS 192.168.31.10 | 21 |
| Common | DNS | nslookup dns1.hotel.local → 192.168.31.10; printer1.hotel.local → 192.168.10.5 | 24 |
| Common | Printers | PC2 → PR1 192.168.10.5 4/4; PC6 → PR2 192.168.30.5 4/4 | 27, 28 |
| Common | AP registration | WC1: AP1, AP2 Online; WC2: AP3, AP4 Online | 34, 40 |
| Common | Wi-Fi clients ↔ gateway | LT1 .20.22, TB1 .21.23, LT2 .40.23, LT3 .41.22 – gateway pings answered (captured runs 3/4, previous runs 4/4) | 45–48 |
| RIPv2 | show ip protocols (R1) | RIP v2 send/receive, auto-summary not in effect, source 10.0.0.2 | 54 |
| RIPv2 | Remote LAN (R1) | `R 192.168.31.0/24 [120/2] via 10.0.0.2, Serial0/0/0` | 55 |
| RIPv2 | PC1 → DNS1 | 4/4, TTL 125; tracert 192.168.10.1 → 10.0.0.2 → 10.0.0.6 → 192.168.31.10 | 56, 57 |
| RIPv2 | Guest TB1 → DNS1 (allowed) / → PC1 (blocked) | 4/4 / Destination host unreachable from 192.168.21.1 | 58, 59 |
| RIPv2 | Guest LT3 → DNS1 (allowed) / → PC4 (blocked) | 4/4 / Destination host unreachable from 192.168.41.1 | 60 |
| OSPF | Neighbours on R2 | 1.1.1.1 FULL (Se0/0/0), 3.3.3.3 FULL (Se0/0/1) | 64 |
| OSPF | Remote LAN (R1) | `O 192.168.31.0/24 [110/129] via 10.0.0.2, Serial0/0/0` | 65 |
| OSPF | PC1 → DNS1 | 4/4, TTL 125; same tracert path | 66, 67 |
| RIPv2 reopened | Route + PC1 (now 192.168.10.21) → DNS1 | R route present, no gaps; 1st run 3/4, 2nd run 4/4; LT1→GW and LT3→DNS1 4/4 | 68, 69 |
| OSPF reopened | Route + PC1 192.168.10.22 → DNS1 | O route present, neighbours FULL; 1st run 3/4, 2nd run 4/4; LT2→GW and TB1→DNS1 4/4 | 70, 71 |

TTL 125 on the PC1 → DNS1 pings = three routers on the path (R1, R2, R3).

## 10. Notes and unresolved items

- **Separate building views not captured.** The full overview (01, 72) shows both buildings with readable names, but
  zoomed per-building views were not produced: the connector has no canvas zoom/scroll control and screen control was
  not used for that step.
- No outline rectangles were drawn (optional in the brief).
- Wireless pings in Packet Tracer often lose the first packet; captured runs show 3/4 where the run just before was 4/4.
- Screenshot 05 shows two rejected `show controllers … | include` lines above the valid output (the filter is not
  supported on that command); screenshot 58 shows the guest failures before the CAPWAP ACL fix above the final results.
- WLC GUI quirk: a WLAN/AP group is only stored after **New → fill fields (commit each with Tab/Enter) → Save**; two
  Saves on WC2 had to be repeated (steps 37 and 38 in the index).
- Device model labels (e.g. "2911") are Packet Tracer's default labels and were left visible.
